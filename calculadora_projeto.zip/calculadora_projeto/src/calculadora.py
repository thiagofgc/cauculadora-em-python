def somar(a, b):
    return a + b

def subtrair(a, b):
    return a - b

def multiplicar(a, b):
    return a * b

def dividir(a, b):
    if b == 0:
        return "Erro: divisao por zero"
    return a / b

def exibir_menu():
    print("\nCalculadora em Python")
    print("1 - Somar")
    print("2 - Subtrair")
    print("3 - Multiplicar")
    print("4 - Dividir")
    print("0 - Sair")

if __name__ == "__main__":
    while True:
        exibir_menu()
        escolha = input("Escolha uma operacao: ")

        if escolha == "0":
            print("Saindo...")
            break

        if escolha not in ["1", "2", "3", "4"]:
            print("Opcao invulida.")
            continue

        try:
            num1 = float(input("Digite o primeiro numero: "))
            num2 = float(input("Digite o segundo numero: "))
        except ValueError:
            print("Entrada invalida. Digite numeros validos.")
            continue

        if escolha == "1":
            resultado = somar(num1, num2)
        elif escolha == "2":
            resultado = subtrair(num1, num2)
        elif escolha == "3":
            resultado = multiplicar(num1, num2)
        elif escolha == "4":
            resultado = dividir(num1, num2)

        print(f"Resultado: {resultado}")
