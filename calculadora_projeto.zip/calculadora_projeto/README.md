# 🧮 Calculadora em Python

Este projeto implementa uma calculadora simples no terminal com as quatro operações básicas: soma, subtração, multiplicação e divisão.

## 🚀 Como executar

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/calculadora_projeto.git
cd calculadora_projeto
```

2. Execute o script:
```bash
python src/calculadora.py
```

## 🧪 Como testar

```bash
pytest
```

## 📄 Licença

Projeto com fins educacionais sob licença MIT.
